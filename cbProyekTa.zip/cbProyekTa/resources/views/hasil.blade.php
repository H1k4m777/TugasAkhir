@extends('home')

@section('content')
<p>{{ $value }}</p>
@endsection