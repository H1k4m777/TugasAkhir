@extends('home')

@section('content')
<h1 class="h3 mb-4 text-gray-800">dashboard</h1>
@endsection