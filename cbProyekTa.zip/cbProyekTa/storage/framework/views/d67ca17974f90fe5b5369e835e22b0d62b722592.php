

<?php $__env->startSection('content'); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Harga Rekomendasi</h6>
    </div>
    <div class="card-body">
        <h4 class="text-center">Rekomendasi harga Laptop adalah <strong><?php echo e($rumus); ?></strong> Juta</h4>
    </div>
</div>

<div class="card shadow mb-4">
    <!-- Card Header - Accordion -->
    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
        <h6 class="m-0 font-weight-bold text-primary">Fuzzifikasi</h6>
    </a>
    <!-- Card Content - Collapse -->
    <div class="collapse" id="collapseCardExample">
        <div class="card-body">
            <h4>Nilai Keanggotaan Kategori Game:</h4>
            <pre>
            <?php echo e(print_r($hitungx_game)); ?>

            </pre>

            <h4>Nilai Keanggotaan Kategori Office:</h4>
            <pre>
            <?php echo e(print_r($hitungx_office)); ?>

            </pre>

            <h4>Nilai Keanggotaan Kategori Editing:</h4>
            <pre>
            <?php echo e(print_r($hitungx_editing)); ?>

            </pre>

            <h4>Nilai Keanggotaan Kategori Programming:</h4>
            <pre>
            <?php echo e(print_r($hitungx_programming)); ?>

            </pre>
            <!-- <a href="defuzzifikasi">hasil</a> -->
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <!-- Card Header - Accordion -->
    <a href="#collapseCardTable" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardTable">
        <h6 class="m-0 font-weight-bold text-primary">inferensi</h6>
    </a>
    <!-- Card Content - Collapse -->
    <div class="collapse" id="collapseCardTable">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Game</th>
                            <th>Editing</th>
                            <th>Office</th>
                            <th>Programming</th>
                            <th>Then</th>
                            <th>Nilai</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Game</th>
                            <th>Editing</th>
                            <th>Office</th>
                            <th>Programming</th>
                            <th>Then</th>
                            <th>Nilai</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $inferensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inferensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($inferensi->game); ?></td>
                            <td><?php echo e($inferensi->edit); ?></td>
                            <td><?php echo e($inferensi->office); ?></td>
                            <td><?php echo e($inferensi->programming); ?></td>
                            <td><?php echo e($inferensi->then); ?></td>
                            <td><?php echo e($inferensi->nilai); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <!-- Card Header - Accordion -->
    <a href="#collapseCardDefuzz" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardDefuzz">
        <h6 class="m-0 font-weight-bold text-primary">Defuzzifikasi</h6>
    </a>
    <!-- Card Content - Collapse -->
    <div class="collapse" id="collapseCardDefuzz">
        <div class="card-body">
            <h4>Nilai Maksimal Low: <?php echo e($max_low); ?></h4>
            <h4>Nilai Maksimal Low Mid: <?php echo e($max_low_mid); ?></h4>
            <h4>Nilai Maksimal Mid: <?php echo e($max_mid); ?></h4>
            <h4>Nilai Maksimal Mid High: <?php echo e($max_mid_high); ?></h4>
            <h4>Nilai Maksimal High: <?php echo e($max_high); ?></h4>

            <h4>Hasil Rumus: <?php echo e($rumus); ?></h4>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hkm\Documents\Kuliah\TugasAkhir\cbProyekTa\resources\views/defuzzifikasi.blade.php ENDPATH**/ ?>