

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">dashboard</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hkm\Documents\Kuliah\TugasAkhir\cbProyekTa\resources\views/dashboard.blade.php ENDPATH**/ ?>