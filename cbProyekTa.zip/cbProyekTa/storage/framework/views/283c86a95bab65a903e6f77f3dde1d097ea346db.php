

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Tables</h1>
<p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
    For more information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official DataTables documentation</a>.</p>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Game</th>
                        <th>Editing</th>
                        <th>Office</th>
                        <th>Programming</th>
                        <th>Then</th>
                        <th>Nilai</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Game</th>
                        <th>Editing</th>
                        <th>Office</th>
                        <th>Programming</th>
                        <th>Then</th>
                        <th>Nilai</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $inferensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inferensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($inferensi->game); ?></td>
                        <td><?php echo e($inferensi->edit); ?></td>
                        <td><?php echo e($inferensi->office); ?></td>
                        <td><?php echo e($inferensi->programming); ?></td>
                        <td><?php echo e($inferensi->then); ?></td>
                        <td><?php echo e($inferensi->nilai); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hkm\Documents\Kuliah\TugasAkhir\cbProyekTa\resources\views/inferensi.blade.php ENDPATH**/ ?>