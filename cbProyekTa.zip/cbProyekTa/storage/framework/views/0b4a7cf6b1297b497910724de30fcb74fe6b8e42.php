

<?php $__env->startSection('content'); ?>
<p><?php echo e($value); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hkm\Documents\Kuliah\TugasAkhir\cbProyekTa\resources\views/hasil.blade.php ENDPATH**/ ?>