

<?php $__env->startSection('content'); ?>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Rules</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Game</th>
                        <th>Editing</th>
                        <th>Office</th>
                        <th>Programming</th>
                        <th>Then</th>

                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Game</th>
                        <th>Editing</th>
                        <th>Office</th>
                        <th>Programming</th>
                        <th>Then</th>

                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $inferensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inferensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($inferensi->game); ?></td>
                        <td><?php echo e($inferensi->edit); ?></td>
                        <td><?php echo e($inferensi->office); ?></td>
                        <td><?php echo e($inferensi->programming); ?></td>
                        <td><?php echo e($inferensi->then); ?></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hkm\Documents\Kuliah\TugasAkhir\cbProyekTa\resources\views/rules.blade.php ENDPATH**/ ?>