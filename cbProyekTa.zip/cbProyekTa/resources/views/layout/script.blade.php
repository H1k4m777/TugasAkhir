<!-- Bootstrap core JavaScript-->
<script src='{{asset("sbadmin/vendor/jquery/jquery.min.js")}}'></script>
<script src='{{asset("sbadmin/vendor/bootstrap/js/bootstrap.bundle.min.js")}}'></script>

<!-- Core plugin JavaScript-->
<script src='{{asset("sbadmin/vendor/jquery-easing/jquery.easing.min.js")}}'></script>

<!-- Custom scripts for all pages-->
<script src='{{asset("sbadmin/js/sb-admin-2.min.js")}}'></script>

<!-- pake akun fontawesome sendiri -->
<script src="https://kit.fontawesome.com/d21ccc1a43.js" crossorigin="anonymous"></script>

<!-- Page level table plugins -->
<script src="{{asset('sbadmin/vendor/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('sbadmin/vendor/datatables/dataTables.bootstrap4.min.js')}}"></script>

<!-- Page level table custom scripts -->
<script src="{{asset('sbadmin/js/demo/datatables-demo.js')}}"></script>